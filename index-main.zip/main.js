jQuery(function ($) {
    /* menu click actions */

    function updateActive() {
        const sectionName = window.location.hash || '#home';

        const $section = $(sectionName);
        $('.section').not($section).removeClass('active');
        $section.addClass('active');

        const link = $(`.menu li a[href='${sectionName}']`);
        const li = link.parent('li');
        $('.menu li').not(li).removeClass('active');
        $(li).addClass('active');
    }


    $(window).on('hashchange', function (e) {
        updateActive();
    });
    // update on init
    updateActive();
})